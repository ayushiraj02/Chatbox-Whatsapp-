#consumers.py


import json
from channels.generic.websocket import AsyncWebsocketConsumer
from asgiref.sync import sync_to_async

from asgiref.sync import sync_to_async
  
 
class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.room_name = self.scope['url_route']['kwargs']['room_name']
        self.room_group_name = f'chat_{self.room_name}'

        await self.channel_layer.group_add(         # Join the room group
            self.room_group_name,
            self.channel_name
        )
        await self.accept()
        print(f"WebSocket connection established for room: {self.room_name}")

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(       # Leave the room group
            self.room_group_name,
            self.channel_name
        )
        print(f"WebSocket connection closed for room: {self.room_name}")

    async def chat_message(self, event):
        message = event['message']
        username = event['username']
        print(f"Sending message to WebSocket: {message} from {username}")

        await self.send(text_data=json.dumps({
            'message': message,
            'username': username,
            'file_url': event.get('file_url', None),
        }))


    @sync_to_async
    def get_to_user(self, from_user_id, room):
        from .models import CustomUser
        """
        Helper method to fetch the other user in the room.
        """
        # Fetch the user who is the recipient of the message
        to_user_id = int(room[0]) if str(room[0]) != str(from_user_id) else int(room[1])
        return CustomUser.objects.get(id=to_user_id)

    
    async def receive(self, text_data):
        print(f"Received WebSocket data: {text_data}")
        data = json.loads(text_data)
        message_content = data['message']
        file_url = data.get('file_url', None)

        from_user = self.scope['user']
        room_name = self.room_name  # Room name from WebSocket connection
        
        # Ensure the room is fetched or created
        room = await self.get_or_create_room(room_name)
        print(f"Room: {room}")

        room_split = room_name.split("_")
        print(f"Room split: {room_split}")

        to_user = await self.get_to_user(from_user.id, room_split)
        print(f"To User: {to_user}")

        # Save message with the room reference
        message = await self.save_message(from_user, to_user, message_content, file_url, room)
        print("Message saved in the database.")

        # Broadcast the message to the room
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'chat_message',
                'message': message_content,
                'username': self.scope['user'].username if self.scope['user'].is_authenticated else 'Anonymous',
                'file_url': file_url,
            }
        )


    @sync_to_async
    def get_or_create_room(self, room_name):
        from .models import Room
        """Get or create the room."""
        room, created = Room.objects.get_or_create(name=room_name)
        return room

    @sync_to_async
    def save_message(self, from_user, to_user, content, file_url, room):
        from .models import Message
        """Save the message in the database."""
        message = Message(from_user=from_user, to_user=to_user, content=content, attachment=file_url, room=room)
        message.save()
        return message

    




