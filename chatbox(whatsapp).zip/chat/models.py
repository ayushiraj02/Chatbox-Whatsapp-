
# Create your models.
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.conf import settings
import uuid


class CustomUser(AbstractUser):
    email = models.EmailField(unique=True)  # Ensure email is unique
    profile_pic = models.ImageField(upload_to='profile_pics/', null=True, blank=True)


class Message(models.Model):
    from_user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='sent_messages')
    to_user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='received_messages')
    content = models.TextField()
    attachment = models.FileField(upload_to='attachments/', null=True, blank=True,default=None)  
    timestamp = models.DateTimeField(auto_now_add=True)

    room = models.ForeignKey('Room', on_delete=models.CASCADE, related_name='messages', null=True, blank=True)  
    
    def __str__(self):
        return f"Message from {self.from_user} to {self.to_user} at {self.timestamp}"

  
class Room(models.Model):
    user1 = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='user1_rooms')
    user2 = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='user2_rooms')
    name = models.CharField(max_length=200, unique=True)

    def __str__(self):
        return self.name

    @classmethod
    def get_or_create_room(cls, user1, user2):
        """
        This method ensures a unique room is created or fetched for a conversation between two users.
        """
        room_name = f"{min(user1.id, user2.id)}_{max(user1.id, user2.id)}"
        room, created = cls.objects.get_or_create(name=room_name, defaults={'user1': user1, 'user2': user2})
        return room