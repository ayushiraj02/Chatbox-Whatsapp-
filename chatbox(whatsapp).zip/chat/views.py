#chat/views.py     uvicorn chatbox.asgi:application --host 127.0.0.1 --port 8000 --reload


# Changes to do
# remove No message yet
# Admin/You
# deleteall message is not delete from db
from django.contrib.auth.models import User,AbstractUser
from django.shortcuts import render, redirect,get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm
from .forms import CustomUserCreationForm
from django.contrib import messages
from .models import *
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.core.files.storage import FileSystemStorage



def register_view(request):
    form = CustomUserCreationForm()  # Initialize the form here for both GET and POST requests
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST, request.FILES)
        if form.is_valid():
            user = form.save() 
            username = form.cleaned_data.get('username')
            messages.success(request, f'Account created for {username}!')
            login(request, user)  
            return redirect('home') 
        # else:
        #     messages.error(request, "Registration failed. Please correct the errors below.")
    
    return render(request, 'register.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')  

    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')  
        else:
            messages.error(request, "Invalid login credentials.")
    else:
        form = AuthenticationForm()
    
    return render(request, 'login.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('login') 


@login_required
def home(request):
    users = CustomUser.objects.exclude(id=request.user.id)  
    return render(request, 'home.html', {'users': users})


@login_required
def chat_view(request, username):
    to_user = CustomUser.objects.get(username=username)
    room = Room.get_or_create_room(request.user, to_user)
   
    
    messages = Message.objects.filter(room=room).order_by('timestamp').all()
    print("from_user",request.user)
    print("to_user",to_user)

    # Pass the messages to the template
    return render(request, 'chat.html', {'room_name': room.name,'messages': messages,'to_user':to_user})


@csrf_exempt
def upload_file(request):
    if request.method == 'POST' and request.FILES.get('file'):
        print("File upload initiated.")
        file = request.FILES['file']
        fs = FileSystemStorage()
        filename = fs.save(file.name, file)
        file_url = fs.url(filename)
        print(f"File saved: {file_url}")

        message_content = request.POST.get('message', '')
        room_name = request.POST.get('room', '')
        print(f"Message content: {message_content}, Room: {room_name}")
        try:
            room = Room.objects.get(name=room_name)
        except Room.DoesNotExist:
            print("Room not found.")
            return JsonResponse({'error': 'Room not found'}, status=400)

        from_user = request.user
        to_user = room.user1 if room.user2 == from_user else room.user2
        print(f"From User: {from_user}, To User: {to_user}")

        message = Message(
            from_user=from_user, 
            to_user=to_user, 
            content=message_content, 
            attachment=file_url
        )
        message.save()
        print("Message saved successfully.")
        return JsonResponse({'file_url': file_url})
    print("Invalid request.")
    return JsonResponse({'error': 'Invalid request'}, status=400)



@csrf_exempt
def delete_messages(request, room_name):
    if request.method == 'POST':
        if not request.user.is_authenticated:
            return JsonResponse({'success': False, 'error': 'Authentication required'}, status=401)
        room = get_object_or_404(Room, name=room_name)
        print("Room",room)
        # Verify if the requesting user is part of the room
        if request.user != room.user1 and request.user != room.user2:
            return JsonResponse({'success': False, 'error': 'You are not authorized to delete messages in this room'}, status=403)
        messages = Message.objects.filter(room=room)
        print("------",messages)  
        print(messages.count())
        
        # Delete all messages in the room
        msgs = Message.objects.all()
        for m in msgs:
            print('***', m.room)
        deleted_count, _ = Message.objects.filter(room=room).delete()
        print(f"Deleted {deleted_count} messages from room: {room_name}")

        messages = Message.objects.filter(room=room)
        print("afterdelete",messages)  
        print(messages.count())
        
        return JsonResponse({'success': True, 'deleted_count': deleted_count})
    return JsonResponse({'success': False, 'error': 'Invalid request method'}, status=400)



#  after sending a file, it's being uploaded and then displayed again when the page is refreshed. This is happening because the file URL is being sent to the WebSocket, and upon refreshing the page, the server sends the same data to the client, which results in duplicating the file.